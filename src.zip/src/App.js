import React, { Component } from 'react';
import './App.css';
import axios from 'axios';
import AllArticles from './components/allArticles/allArticles';

class App extends Component {
  state = {
    articles: {
      author: null,
      description: null,
      title: null,
      publishedAt: null,
      urlToImage: null,
      url: null,
      source: {
        id: null,
        name: null
      }
    }
  }



  componentDidMount(){
    
  }

  render() {
    axios
      .get('https://newsapi.org/v2/top-headlines?' +
        'country=in&' +
        'apiKey=1fe94e1f7eb747b3a5879a48ba736409')
      .then(res => {
        const articles = res.data.articles;
        // Set state with result
        console.log(articles);
        this.setState({ articles: articles});
      })
      .catch(error => {
        console.log(error);
      });
    return (
      <div className="App">
          <AllArticles allarticles={this.state.articles}/>
      </div>
    );
  }
}

export default App;
