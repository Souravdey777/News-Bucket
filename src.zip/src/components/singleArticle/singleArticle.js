import React, { Component } from 'react';
import ClassNames from './singleArticle.module.css';

class SingleArticle extends Component {
  render() {
    console.log(this.props.articles);
    return (
      <div className={ClassNames.Article}>
        <div className={ClassNames.Header}>
        {this.props.articles.title}
        </div>
        <img src={this.props.articles.urlToImage} alt= ' '/>
        Author: {this.props.articles.author}<br/>
        Description: {this.props.articles.description}<br/><br/>
        Contents: {this.props.articles.content}
        <a href={this.props.articles.url}>click here for more details</a>
      </div>
    );
  }
}

export default SingleArticle;
