import React from 'react';
import SingleArticle from '../singleArticle/singleArticle';

    const AllArticles =props=>{
    let all_articles = Object.keys(props.allarticles)
    .map(igKey=>{
        return[...Array(props.allarticles[igKey])].map((arg,i)=>{
            return<SingleArticle key={i} articles={arg}/>
        })  
    });

    return(
        <div>{console.log(all_articles)}</div>
    );
}

export default AllArticles;